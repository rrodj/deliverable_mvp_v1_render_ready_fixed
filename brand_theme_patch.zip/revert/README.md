# Revert Instructions
To revert the brand theme changes, overwrite the patched files with the originals in this `revert/` folder:
- `frontend/index.html`
- `frontend/src/main.tsx`
Then rebuild the frontend.
